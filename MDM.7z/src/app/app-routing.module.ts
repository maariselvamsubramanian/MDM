import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {RegistrationComponent} from 'src/app/registration/registration.component';
import {HelpdeskComponent } from 'src/app/helpdesk/helpdesk.component';
import {HomeComponent} from 'src/app/home/home.component';
const routes: Routes = [
  {
    path:'',
   redirectTo:'home',
   pathMatch:'full'
  },
  {
    path: 'home',
    component: HomeComponent
  },
  {
  path:'register',
  component: RegistrationComponent
},{
  path: 'helpdesk',
  component: HelpdeskComponent
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
