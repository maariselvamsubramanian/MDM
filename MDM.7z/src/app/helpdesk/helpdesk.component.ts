import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-helpdesk',
  templateUrl: './helpdesk.component.html',
  styleUrls: ['./helpdesk.component.scss'],
})
export class HelpdeskComponent implements OnInit {
  helpForm: FormGroup;
  isSubmitted: boolean = false;
  constructor() {}

  ngOnInit(): void {
    this.helpForm = new FormGroup({
      issueAddress: new FormControl('', Validators.required),
      issueType: new FormControl('', Validators.required),
      landmark: new FormControl('', Validators.required),
    });
  }

  // headerClicked(event) {
  //   console.log(event);
  // }

  onSubmit() {
    this.isSubmitted = true;
    console.log(this.helpForm.value);
  }
}
