import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss'],
})
export class RegistrationComponent implements OnInit {
  mobileNumber: number;
  otp: number;
  pincode: number;
  vehicleMake: string;
  userName: string;
  registerForm: FormGroup;

  constructor() {}

  ngOnInit(): void {
    const emailPattern = '^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$';
    const emailPatterns = '^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$';

    this.registerForm = new FormGroup({
      userName: new FormControl('', Validators.required),
      contactNumber: new FormControl('', [
        Validators.required,
        Validators.maxLength(10),
        Validators.pattern('^((\\+91-?)|0)?[0-9]{10}$'),
      ]),
      pincode: new FormControl('', [
        Validators.required,
        Validators.maxLength(6),
      ]),
      vehicleMake: new FormControl('', Validators.required),
      email: new FormControl('', [Validators.required, Validators.email]),
      gender: new FormControl('', Validators.required),
      manufactureYear: new FormControl('', Validators.required),
      vehicleModel: new FormControl('', Validators.required),
    });

    this.registerForm
      .get('contactNumber')
      .valueChanges.subscribe((formControl) => {
        console.log('trigger from form control');
        console.log(formControl);
      });
  }

  moveNext(field: string) {}

  onSubmit() {
    console.log(this.registerForm);
  }

  get email() {
    return this.registerForm.get('email');
  }

  get contactNumber() {
    return this.registerForm.get('contactNumber');
  }

  phoneNumberValidation(event) {
    if (
      (event.keyCode >= 48 && event.keyCode <= 57) ||
      (event.keyCode >= 96 && event.keyCode <= 105) ||
      (event.keyCode >= 35 && event.keyCode <= 40) ||
      event.keyCode == 8 ||
      event.keyCode == 46 ||
      event.keyCode == 9
    ) {
      // 0-9 only
    } else {
      event.preventDefault();
    }
  }

  validateFromPhone() {
    return this.validate('phone');
  }

  validateFromPincode() {
    return this.validate('pincode');
  }

  validate(triggerFrom: string) {
    let status: boolean = false;
    switch (triggerFrom) {
      case 'phone':
        if (this.registerForm.get('contactNumber').value.length !== 10) {
          return (status = true);
        }
      case 'pincode':
        if (this.registerForm.get('pincode').value.length !== 6) {
          return (status = true);
        }
    }
    return status;
  }
}
